# Common enums and constants
from typing import List

EnergyTypes: List[str] = [
    "Electricity",
    "Natural Gas",
    "Steam",
    "Fuel Oil 2",
    "Fuel Oil 4",
]

# years when the carbon emissions threshold change
StartYears: List[int] = [2024, 2030, 2035, 2040, 2050]